function HC = histCost(SCx, SCy)
% Chi^2-Test zum Vergleich zweier Histogramme
    function hc = histCost1d(scx, scy)
        a = scx(:);
        b = scy(:);
        diff = a - b;
        sum_ab = a + b;
        % Vermeide Division durch Null
        valid = sum_ab ~= 0;
        hc = 0.5 * sum((diff(valid).^2) ./ sum_ab(valid)); 
    end
    % TODO
    if size(SCx, 3) == size(SCy, 3) & size(SCx, 3) == 1
        HC = histCost1d(SCx, SCy);
    else
        m = size(SCx, 3);
        n = size(SCy, 3);
        hcMat = zeros(m, n);
        for i = 1:m
            for j = 1:n
                hcMat(i, j) = histCost1d(SCx(:, :, i), SCy(:, :, j));
            end
        end
        rowMin = min(hcMat, [], 2);
        colMin = min(hcMat);
        HC = (sum(rowMin(:)) / m) + (sum(colMin(:) / n));
    end
end
