% Findet Geraden in einem Bild mit Hilfe der Matlab-eigenen Funktionen zur
% Hough-Transformation

%% Bild einlesen und darstellen
I = im2double(imread('./bilder/wire_bond1.tif'));
if size(I, 3) > 1
    I = rgb2gray(I);
end

figure(1); clf; subplot(2, 2, 1);
imshow(I);
title('Bild');

%% Kantenbild erstellen und darstellen
%
%  Befehle: edge, imshow/image/imagesc
figure(1); subplot(2, 2, 3);            % (sub)figure anwählen


    % TODO


title('Kantenbild');

%% Hough-Transformation und Darstellung der Akkumulatormatrix
%
%  Befehle: hough, imagesc
figure(1); subplot(2, 2, [2, 4]);       % (sub)figure anwählen


    % TODO


title('Akkumulatormatrix');    
    
%% Maxima der Akkumulatormatrix H bestimmen
%  und in Darstellung plotten
%
%  Befehle: houghpeaks, plot
figure(1); subplot(2, 2, [2, 4]);       % (sub)figure anwählen


    % TODO


hold off;

%% Geraden zu den entsprechenden Maxima in das Bild plotten
%
%  getEndpoints(I, theta, rho) gibt Endpunkte der implizit gegebenen
%  Geraden mit den Parametern theta und rho zurück. Die relevanten
%  Parameter können mit der Rückgabe von houghpeaks aus R und T bestimmt 
%  werden.
%
%  Befehl: plot
figure(1); subplot(2, 2, 1);            % (sub)figure anwählen

hold on;


    % TODO


hold off;
