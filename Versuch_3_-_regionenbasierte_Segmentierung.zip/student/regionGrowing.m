function S = regionGrowing(I, xStart, yStart, threshold)
% Eingabe: I              - Bild
%          xStart, yStart - Saatpunkt
%          threshold      - Schwellwert für die Ähnlichkeit in der Region
%
% Einfacher Steppenbrand-Algorithmus.

    % TODO

end
