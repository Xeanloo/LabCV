%% Laden der Daten

    % TODO
    
%% Schätzung der Parameter der Verteilungen

    % TODO
    
%% Darstellung der geschätzen Verteilungen

    % TODO
    
%% Naiver Bayes Klassifikator
%  Variablen unabhängig, eindimensionale Normalverteilungen

    % TODO
   
%% Bayes Klassifikator
%  Variablen abhängig, mehrdimensionale Normalverteilung

    % TODO
