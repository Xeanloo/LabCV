function HC = histCost(SCx, SCy)
% Chi^2-Test zum Vergleich zweier Histogramme
    
    
    % TODO
    
    
end
