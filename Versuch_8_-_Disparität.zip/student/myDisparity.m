function D = myDisparity(imgLeft, imgRight, maxDisparity)
    
    % TODO

end