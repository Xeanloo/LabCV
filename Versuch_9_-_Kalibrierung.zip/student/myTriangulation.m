function X = myTriangulation(x1, x2, P1, P2)
    
    % TODO
    
end
